---
name: The Pirbright Institute
shortname: Pirbright
website: https://www.pirbright.ac.uk/
logo: Pirbright logo_RGB_Large.jpg
---

The Pirbright Institute is a world leading centre of excellence in research and surveillance of viral diseases of farm animals and viruses that spread from animals to humans. It receives strategic funding from the Biotechnology and Biological Sciences Research Council (BBSRC), and works to enhance capability to contain, control and eliminate economically and medically important diseases through highly innovative fundamental and applied bioscience.